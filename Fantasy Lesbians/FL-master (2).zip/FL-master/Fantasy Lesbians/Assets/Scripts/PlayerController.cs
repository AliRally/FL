﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour 
{

    private Vector3 pos;
    private Vector3 endpos;
    private float gridSize = 64f;
    private float moveSpeed = 128f;

    bool lerp;

    public bool isMoving = false;

    public bool wallLeft = false;
    public bool wallRight = false;
    public bool wallUp = false;
    public bool wallDown = false;

    private float factor, t;
    private bool allowDiagonals = false;
    private bool correctDiagonalSpeed = true;
    private Vector2 input;

    GridMove GM = new GridMove();

	// Use this for initialization
	void Start () 
    {
        pos = transform.position;
        //endpos = transform.position;
       // lerp = false;
        
	}
	
	// Update is called once per frame
	void Update () 
    {

        if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow) && wallRight == false)
        {
            //pos = transform.position;
            endpos = new Vector3(pos.x += gridSize, pos.y, 0);
            isMoving = true;
            //lerp = true;
        }
        else if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow) && wallLeft == false)
        {
           // pos = transform.position;
            endpos = new Vector3(pos.x -= gridSize, pos.y, 0);
            isMoving = true;
            //lerp = true;
        }
        else if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow) && wallUp == false)
        {
            //pos = transform.position;
            endpos = new Vector3(pos.x, pos.y += gridSize, 0);
            isMoving = true;
            //lerp = true;
        }
        else if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow) && wallDown == false)
        {
           // pos = transform.position;
            endpos = new Vector3(pos.x, pos.y -= gridSize, 0);
            isMoving = true;
            //lerp = true;
        }
        //lerpin();
	}

    public IEnumerator lerpin()
    {
        if (allowDiagonals && correctDiagonalSpeed && input.x != 0 && input.y != 0)
        {
            factor = 0.7071f;
        }
        else
        {
            factor = 1f;
        }

        while (t < 1f)
        {
            t += Time.deltaTime * (moveSpeed / gridSize) * factor;
            transform.position = Vector3.Lerp(pos, endpos, t);
            yield return null;
        }
    }
}
