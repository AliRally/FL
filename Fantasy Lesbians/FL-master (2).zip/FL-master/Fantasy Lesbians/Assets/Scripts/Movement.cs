﻿using UnityEngine;
using System.Collections;

public class Movement : MonoBehaviour
{

    public Vector2 pos, startPos;
    public bool isMoving = false;

    private float gridSize = 64f;
    private float speed = 128f;
    private float t;

    public bool wallLeft = false;
    public bool wallRight = false;
    public bool wallUp = false;
    public bool wallDown = false;


    // Use this for initialization
    void Start()
    {
        startPos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        CheckInput();
        

        if (isMoving)
        {
            transform.position = pos;
            isMoving = false;
        }
        //t += Time.deltaTime * (speed / gridSize) * speed;
        //transform.position = Vector3.Lerp(startPos, pos, t);
    }

    private void CheckInput()
    {
        if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow) && wallRight == false)
        {
            pos += Vector2.right * gridSize;
            isMoving = true;
        }
        else if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow) && wallLeft == false)
        {
            pos -= Vector2.right * gridSize;
            isMoving = true;
        }
        else if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow) && wallUp == false)
        {
            pos += Vector2.up * gridSize;
            isMoving = true;
        }
        else if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow) && wallDown == false)
        {
            pos -= Vector2.up * gridSize;
            isMoving = true;
        }
    }
}
