﻿using UnityEngine;
using System.Collections;

public class pawnClass : MonoBehaviour {

    public Transform target;
    public float speed = 3f;
    public float attack1Range = 1f;
    public int pawnDamage = 2;
    public float timeBetweenAttacks;
    public int pawnHP = 10;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
